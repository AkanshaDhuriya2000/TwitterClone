
import React from 'react'
import { GoFileMedia } from 'react-icons/go'
import { AiOutlineFileGif, AiOutlineSchedule } from 'react-icons/ai'
import { BiPoll } from 'react-icons/bi'
import { BsEmojiSmile } from 'react-icons/bs'


function CreatePost () {
    return (
        <div className='border-b'>
            <div className='flex flex-row items-center p-3'>
                <div className='w-12 h-12  rounded-full bg-slate-400'></div>
                <div className='ml-3 font-normal text-xl text-gray-500'>
                    What is happening?!</div>
            </div>
            <div className='flex flex-row justify-around'>
                <div className='flex flex-row text-xl text-blue-400 mb-3 '>
                    <div className='ml-3  p-2 h-9 w-9  cursor-pointer rounded-full  hover:bg-slate-200'><GoFileMedia /></div>
                    <div className='ml-3  p-2 h-9 w-9  cursor-pointer rounded-full  hover:bg-slate-200'>  <AiOutlineFileGif /></div>
                    <div className='ml-3  p-2 h-9 w-9 cursor-pointer rounded-full  hover:bg-slate-200'><BiPoll /></div>
                    <div className='ml-3  p-2 h-9 w-9 cursor-pointer rounded-full  hover:bg-slate-200'> <BsEmojiSmile /></div>
                    <div className='ml-3  p-2 h-9 w-9 cursor-pointer rounded-full  hover:bg-slate-200'><AiOutlineSchedule /></div>
                </div>

                <button className='w-[100px] py-1 mb-2 ml-10 rounded-full
                        hover: bg-blue-500  text-white text-lg ' >
                    Tweet
                </button>
            </div>

        </div>


    )
}

export default CreatePost




