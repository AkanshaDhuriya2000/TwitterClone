import React from 'react'
import CreatePost from './CreatePost'
import Post from './Post'
function Feed () {
    return (
        <div className='ml-[255px] w-[500px] border-l border-r h-screen'>
            <div className='text-xl p-3 font-semibold border-b'>Home</div>

            {/* <CreatePost /> */ }
            <Post />
            <Post />
        </div>


    )
}

export default Feed