import React from 'react'

function RightSidebar () {
    return (
        <div className='fixed ml[755px]'>
            <div>Who to Follow </div>
            <div>
                <div>
                    {/* avatar */ }
                    <div className='w-12 h-12 rounded-full bg-slate-400'></div>




                </div>

            </div>




        </div>
    )
}

export default RightSidebar