
import './App.css';
import HomePage from './Components/HomePage';
import Register from './Components/Register';
import SignIn from './Components/SignIn';

function App () {

  const user = ""

  return (
    <div>
      {
        user ?
          <HomePage />
          :
          <div className='flex flex-row items-center justify-center'>
            <Register />
            {/* <SignIn /> */ }
          </div>


      }
    </div>

  );
}

export default App;
